package today;

import org.testng.annotations.Test;

public class feb1 {
	@Test
	public static void login() {
		System.out.println("this is login ");
	}

}
