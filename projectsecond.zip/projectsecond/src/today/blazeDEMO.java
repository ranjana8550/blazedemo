package today;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class blazeDEMO {
	@Test
	public static void FlightBooking()
	{
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver=new ChromeDriver();
		String url="https://blazedemo.com/";
		driver.get(url);
	Select departure=new Select(driver.findElement(By.xpath("//select[@name='fromPort']")));
	departure.selectByIndex(5);
	Select destination=new Select(driver.findElement(By.xpath("//select[@name='toPort']")));
	destination.selectByIndex(4);
	driver.findElement(By.xpath("//input[@type='submit']")).click();
	driver.findElement(By.xpath("(//input[@type='submit'])[1]")).click();
	driver.findElement(By.id("inputName")).sendKeys("ranjana");
	driver.findElement(By.id("address")).sendKeys("dhangadhi");
	driver.findElement(By.id("city")).sendKeys("chatakpur");
	driver.findElement(By.id("state")).sendKeys("7");
	driver.findElement(By.id("zipCode")).sendKeys("123");
	Select cardType=new Select(driver.findElement(By.id("cardType")));
	cardType.selectByIndex(0);
	driver.findElement(By.id("creditCardNumber")).sendKeys("12345");
	driver.findElement(By.id("creditCardMonth")).sendKeys("6");
	driver.findElement(By.id("creditCardYear")).sendKeys("2020");
	driver.findElement(By.id("nameOnCard")).sendKeys("ranjanapant");
	driver.findElement(By.xpath("(//label[@class='checkbox'])")).click();
	driver.findElement(By.xpath("//input[@type='submit']")).click();
	
	
	
	
	
	
	}
        
	
	
	}
